# Namespace for dynamically registered tool wrappers
