The registry.yaml is generated from a Snakemake workflow via:

- pipemind parse WES-Pipeline-Snakemake/workflow -o pipemind/registry/registry.yaml

It contains typed tool and resource schemas used by the MCP server and DAG builder.